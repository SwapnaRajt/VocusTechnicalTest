﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using KBSData;
using KBSDataAccessManager;
using KBSDataModels;

namespace DodoRestAPI.Controllers
{
    public class CustomerProductsController : ApiController
    {
        // api/CustomerProducts/1
        public HttpResponseMessage GetCustomerProducts(int id)
        {
            if (id == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, "CustomerId does not exist");
            }

            try
            {
               // List<CustomerProduct> customerProducts = new List<CustomerProduct>();
                CustomerProduct customerProduct = new CustomerProduct();
                CutomerPaymentManager cutomerPaymentManager = new CutomerPaymentManager();
                CustomerPayment customerPaymentDetails = cutomerPaymentManager.GetCustomersPaymentsByID(id);
                if (customerPaymentDetails != null)
                {
                    
                    customerProduct.CustomerName = customerPaymentDetails.customer.CustomerName;
                    customerProduct.Products = customerPaymentDetails.product;
                }

                return Request.CreateResponse(HttpStatusCode.OK, customerProduct);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }
        }
    }
}
