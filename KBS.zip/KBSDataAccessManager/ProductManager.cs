﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KBSDataModels;

namespace KBSDataAccessManager
{
    public class ProductManager
    {
        public ProductManager()
        {
        }

        public Product GetProductById(int productid)
        {
            Product product = new Product();

            using (var kbsManager = new KbsDataManager())
            {
                string query = @"Select P.ID,P.ProductName,P.Price,S.ServiceName from Product P 
                                 Left Join[dbo].[ServiceType] S ON P.ServiceType = S.ID where P.ID = @productId";
                kbsManager.SetQuery(query);
                kbsManager.SetParameter("@productId", productid);
                var reader = kbsManager.ExecuteQuery();
                DataTable dt = new DataTable();
                dt.Load(reader);
                kbsManager.CloseConnection();
                int numRows = dt.Rows.Count;
                if (numRows > 0)
                {
                    product.ProductID = (dt.Rows[0]["CustomerId"] != DBNull.Value)
                        ? Convert.ToInt32(dt.Rows[0]["CustomerId"])
                        : 0;
                    product.ProductName = (dt.Rows[0]["ProductName"] != DBNull.Value)
                        ? (string) dt.Rows[0]["ProductName"]
                        : " ";
                    product.ServiceName = (dt.Rows[0]["ServiceName"] != DBNull.Value)
                        ? (string) dt.Rows[0]["ServiceName"]
                        : " ";
                }
            }

            return product;
        }

        public Product GetProductByCustomerId(int customerid)
        {
            Product product = new Product();

            using (var kbsManager = new KbsDataManager())
            {
                string query = @"Select CP.CustomerId as CustomerId,P.ProductName,S.ServiceName
                                from[dbo].[CutomerPayment] CP
                                Left Join Product P ON CP.[ProductId] = P.ID
                                Left Join [dbo].[ServiceType] S ON P.ServiceType = S.ID
                                WHERE CP.CustomerId=@customerID ";
                kbsManager.SetQuery(query);
                kbsManager.SetParameter("@customerID", customerid);
                var reader = kbsManager.ExecuteQuery();
                DataTable dt = new DataTable();
                dt.Load(reader);
                kbsManager.CloseConnection();
            }

            return product;
        }
}
}

    
