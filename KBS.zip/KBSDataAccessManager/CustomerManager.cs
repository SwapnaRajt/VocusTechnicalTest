﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KBSDataAccessManager;
using KBSDataModels;

namespace KBSDataAccessManager
{
    public class CustomerManager
    {
        public CustomerManager(){
        }

        public Customer GetCustomersByID(int customerid)
        {
            Customer customer = null;
            using (var kbsManager = new KbsDataManager())
            {
                string query = "SELECT * FROM Customers WHERE ID=@customerID ";
                kbsManager.SetQuery(query);
                kbsManager.SetParameter("@customerID", customerid);

                var reader = kbsManager.ExecuteQuery();
                DataTable dt = new DataTable();
                dt.Load(reader);
                kbsManager.CloseConnection();
                int numRows = dt.Rows.Count;

                if (numRows>0)
                {
                    customer = new Customer();
                   customer.ID = (dt.Rows[0]["CustomerId"] != DBNull.Value)
                        ? Convert.ToInt32(dt.Rows[0]["CustomerId"])
                        : 0;
                   customer.CustomerName =
                        (dt.Rows[0]["FirstName"] != DBNull.Value || dt.Rows[0]["LastName"] != DBNull.Value)
                            ? ((string)dt.Rows[0]["FirstName"] + " " +(string)dt.Rows[0]["LastName"])
                            : " ";

                    customer.HomeAddress = (dt.Rows[0]["HomeAddress"] != DBNull.Value)
                        ? (string)dt.Rows[0]["HomeAddress"]
                        : " ";
                    customer.ContactNumber = (dt.Rows[0]["ContactNumber"] != DBNull.Value)
                        ? (string)dt.Rows[0]["ContactNumber"] : " ";
                }
            }
            return customer;
        }

        
}
    
    
}
