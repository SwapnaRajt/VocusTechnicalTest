﻿using KBSDataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using KBSDataAccessManager;

namespace DodoRestAPI.Controllers
{
    public class CustomerDetailsController : ApiController
    {

        // GET api/CustomerDetails/5
        public HttpResponseMessage GetCustomerDetails(int id)
        {
            if (id == 0)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, "CustomerId does not exist");
            }

            try
            {
                Customer customer = new Customer();
                CutomerPaymentManager cutomerPaymentManager = new CutomerPaymentManager();
                CustomerPayment customerPaymentDetails = cutomerPaymentManager.GetCustomersPaymentsByID(id);
                if (customerPaymentDetails != null)
                {
                    customer = customerPaymentDetails.customer;
                    //customers.Add(customer);
                }

                return Request.CreateResponse(HttpStatusCode.OK, customer);
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.ExpectationFailed, ex.Message);
            }

        }
    }   

}
