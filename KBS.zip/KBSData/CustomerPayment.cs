﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KBSDataModels
{
    public class CustomerPayment
    {
        public Customer customer { get; set; }
        public List<Product> product { get; set; }
        public double Totaldebit { get; set; }
        public double Totalcredit { get; set; }
    }
}
