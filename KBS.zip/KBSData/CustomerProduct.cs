﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using KBSDataModels;

namespace KBSData
{
    [DataContract]
    public class CustomerProduct
    {
        [DataMember(Name = "CustomerName", EmitDefaultValue = false, Order = 0)]
        public string CustomerName { get; set; }

        [DataMember(Name = "Products", EmitDefaultValue = false, Order = 1)]
        public List<Product> Products { get; set; }
    }
}
