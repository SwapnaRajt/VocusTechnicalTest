﻿using System;
using KBSData;
using KBSDataAccessManager;
using KBSDataModels;

namespace Billit
{
    public partial class CustomerDashboard : System.Web.UI.Page
    {
         
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            int customerId = String.IsNullOrWhiteSpace(txtSearch.Text) ? 0 : Convert.ToInt32(txtSearch.Text);
            if (customerId != 0)
            {
                CutomerPaymentManager cutomerPaymentManager = new CutomerPaymentManager();
                CustomerPayment customerPaymentDetails = cutomerPaymentManager.GetCustomersPaymentsByID(customerId);
                if (customerPaymentDetails != null)
                {
                    CustomerProduct customerProduct = new CustomerProduct();
                    customerProduct.CustomerName = customerPaymentDetails.customer.CustomerName;
                    customerProduct.Products = customerPaymentDetails.product;

                    DisplayCustomerDetails(customerPaymentDetails.customer);
                    DisplayProducts(customerProduct);
                    DisplayAmountOwing(customerPaymentDetails);
                }

            }

        }
        private void DisplayCustomerDetails(Customer customer)
        {
            if (customer != null)
            {
                CustomerName.Text = String.IsNullOrWhiteSpace(customer.CustomerName)? " " : customer.CustomerName;
                CustomerAddress.Text = String.IsNullOrWhiteSpace(customer.HomeAddress) ? " " : customer.HomeAddress;
                CustomerContactNumber.Text = String.IsNullOrWhiteSpace(customer.ContactNumber) ? "" : customer.ContactNumber;
            }
        }
        private void DisplayProducts(CustomerProduct customerProduct)
        {
            if (customerProduct != null)
            {
                ProductContactName.Text = String.IsNullOrWhiteSpace(customerProduct.CustomerName)
                    ? String.Empty
                    : customerProduct.CustomerName;
                grvProducts.DataSource = (customerProduct.Products.Count == 0) ? null : customerProduct.Products;
                grvProducts.DataBind();
            }
        }
        private void DisplayAmountOwing(CustomerPayment customerPaymentDetails)
        {
            CustomerAmountOwing.Text = Convert.ToString(customerPaymentDetails.Totalcredit- customerPaymentDetails.Totaldebit);
        }

}
}