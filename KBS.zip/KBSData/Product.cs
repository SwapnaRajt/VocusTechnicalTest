﻿
using System.Runtime.Serialization;


namespace KBSDataModels
{
    [DataContract]
    public class Product
    {
        [DataMember(Name = "ProductID", EmitDefaultValue = false, Order = 0)]
        public int ProductID { get; set; }

        [DataMember(Name = "ProductName", EmitDefaultValue = false, Order = 1)]
        public string ProductName { get; set; }

        [DataMember(Name = "ServiceName", EmitDefaultValue = false, Order = 2)]
        public string ServiceName { get; set; }

    }
}
