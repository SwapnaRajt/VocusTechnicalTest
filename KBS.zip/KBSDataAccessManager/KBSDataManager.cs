﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using KBSDataModels;

namespace KBSDataAccessManager
{
    public class KbsDataManager : IDisposable
    {
        private SqlConnection connStr =
            new SqlConnection("Data Source=localhost;Initial Catalog=CustomerBillingDatabase;Integrated Security=True");

        private static SqlCommand sqlCommand = new SqlCommand();

        public KbsDataManager()
        {
            CreateSqlCommand();
        }

        public void Dispose()
        {
            sqlCommand.Parameters.Clear();
            sqlCommand?.Dispose();
            if (sqlCommand.Connection!= null)
            {
                sqlCommand.Connection.Close();
            }
        }
        private SqlCommand CreateSqlCommand()
        {
            sqlCommand.Connection = connStr;
            return sqlCommand;
        }
        
        public void SetQuery(string query)
        {
            sqlCommand.CommandText = query;
        }
        public void SetParameter(string parameterKey, object parameterValue)
        {
            sqlCommand.Parameters.Add(new SqlParameter { ParameterName = parameterKey, Value = parameterValue });
        }
        public SqlDataReader ExecuteQuery()
        {
            sqlCommand.Connection.Open();
            SqlDataReader reader = sqlCommand.ExecuteReader();
            return reader;
        }

        public void CloseConnection()
        {
            sqlCommand.Connection.Close();
        }

    }
}
