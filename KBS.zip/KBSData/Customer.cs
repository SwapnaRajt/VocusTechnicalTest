﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace KBSDataModels
{
    [DataContract]
    public class Customer
    {
        [DataMember(Name = "CustomerID", EmitDefaultValue = false, Order = 0)]
        public int ID { get; set; }

        [DataMember(Name = "CustomerName", EmitDefaultValue = false, Order = 1)]
        public string CustomerName { get; set; }

        [DataMember(Name = "HomeAddress", EmitDefaultValue = false, Order = 2)]
        public string HomeAddress { get; set; }

        [DataMember(Name = "ContactNumber", EmitDefaultValue = false, Order = 3)]
        public string ContactNumber { get; set; }
        
    }
}
