﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KBSDataModels;

namespace KBSDataAccessManager
{
    public class CutomerPaymentManager
    {
        public CutomerPaymentManager()
        {
            
        }

        public CustomerPayment GetCustomersPaymentsByID(int customerid)
        {
            CustomerPayment cutomerPayment = new CustomerPayment();
            cutomerPayment.customer = new Customer();
            cutomerPayment.product = new List<Product>();
            using (var kbsManager = new KbsDataManager())
            {
                string query = @"Select CP.CustomerId as CustomerId, C.FirstName,C.LastName,C.HomeAddress,C.ContactNumber,
                                CP.Totalbill,CP.TotalPaid,P.ID as ProductId,P.ProductName,S.ServiceName
                                from[dbo].[CutomerPayment] CP 
                                Left Join Customers C ON CP.CustomerId = C.ID 
                                Left Join Product P ON CP.[ProductId] = P.ID
                                Left Join [dbo].[ServiceType] S ON P.ServiceType = S.ID
                                WHERE CP.CustomerId=@customerID ";

                kbsManager.SetQuery(query);
                kbsManager.SetParameter("@customerID", customerid);

                var reader = kbsManager.ExecuteQuery();

                DataTable dt = new DataTable();
                dt.Load(reader);
                kbsManager.CloseConnection();
                int numRows = dt.Rows.Count;

                if (numRows>0)
                {
                   List<Product> products = new List<Product>();
                    
                        cutomerPayment.customer.ID = (dt.Rows[0]["CustomerId"] != DBNull.Value)
                            ? Convert.ToInt32(dt.Rows[0]["CustomerId"])
                            : 0;
                        cutomerPayment.customer.CustomerName =
                            (dt.Rows[0]["FirstName"] != DBNull.Value || dt.Rows[0]["LastName"] != DBNull.Value)
                                ? ((string)dt.Rows[0]["FirstName"] + (string)dt.Rows[0]["LastName"])
                                : " ";

                        cutomerPayment.customer.HomeAddress = (dt.Rows[0]["HomeAddress"] != DBNull.Value)
                            ? (string)dt.Rows[0]["HomeAddress"]
                            : " ";
                        cutomerPayment.customer.ContactNumber = (dt.Rows[0]["ContactNumber"] != DBNull.Value)
                            ? (string)dt.Rows[0]["ContactNumber"] : " ";

                        double totalcredit = 00.00;
                        double totaldebit = 00.00;
                        foreach (DataRow row in dt.Rows)
                        {
                            Product product = new Product();

                            product.ProductID = (row["CustomerId"] != DBNull.Value)
                                ? Convert.ToInt32(row["CustomerId"])
                                : 0;
                            product.ProductName = (row["ProductName"] != DBNull.Value)
                                ? (string)row["ProductName"] : " ";
                            product.ServiceName = (row["ServiceName"] != DBNull.Value)
                                ? (string)row["ServiceName"] : " ";
                            totalcredit = totalcredit + ((row["Totalbill"] != DBNull.Value)
                                ? Convert.ToDouble(row["Totalbill"])
                                : 00.00);
                            totaldebit = totaldebit + ((row["Totalpaid"] != DBNull.Value)
                                ? Convert.ToDouble(row["Totalpaid"])
                                : 00.00);

                        cutomerPayment.product.Add(product);
                        }

                        cutomerPayment.Totalcredit = totalcredit;
                        cutomerPayment.Totaldebit = totaldebit;

                }
            }
            return cutomerPayment;
        }
    }
}
